//
//  FamilyApp.swift
//  Family
//
//  Created by Turma01-18 on 09/10/24.
//

import SwiftUI

@main
struct FamilyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
