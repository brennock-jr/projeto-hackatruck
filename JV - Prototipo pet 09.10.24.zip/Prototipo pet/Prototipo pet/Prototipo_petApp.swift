//
//  Prototipo_petApp.swift
//  Prototipo pet
//
//  Created by Turma01-23 on 08/10/24.
//

import SwiftUI

@main
struct Prototipo_petApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
