//
//  ContentView.swift
//  Prototipo pet
//
//  Created by Turma01-23 on 08/10/24.
//

import SwiftUI



struct ContentView: View{
    var body: some View{
        NavigationStack{
            ZStack{
                Rectangle()
                    .fill(Color.malva)
                    .edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
                VStack{
                    Image("Logo")
                        .resizable()
                        .scaledToFit()
                        .padding()
                    
                    HStack{
                        NavigationLink(destination: Tab()){
                            Text("Modo 1")
                                .frame(width: 250,height: 40)
                                .background(Color.roxobotao)
                                .font(.headline)
                                .foregroundStyle(Color.black)
                                .cornerRadius(30)
                                .padding()
                        }
                    }
                }
            }
        }
    }
}


struct Tab: View {
    
    var body: some View {
        
       
        TabView{
            Individual()
                .tabItem {
                    Label("Individual", systemImage: "person")
                }
            Familia()
                .tabItem {
                    Label("Familia", systemImage: "person.3")
                }
            Ajustes()
                .tabItem {
                    Label("Ajustes", systemImage: "list.bullet")
                }
        }
        
    }
}

struct Individual: View{
    
    var body: some View{
        
        ZStack{
            Rectangle()
                .fill(Color.white)
                .edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            VStack{
                HStack{
                    Text ("Outubro 2024")
                        .font(.title)
                        .foregroundStyle(Color.black)
                        .bold()
                        .padding()
                    Spacer()
                    Image(systemName: "calendar")
                        .font(.system(size: 40))
                        .padding()
                }
                HStack{
                    Text("Gasto total")
                        .font(.title2)
                        .foregroundStyle(Color.black)
                        .bold()
                        .padding()
                    Spacer()
                    ZStack{
                        Rectangle()
                            .fill(Color.green)
                            .frame(width: 150, height: 40)
                            .cornerRadius(30)
                            .padding()
                        Text("R$ 2.100,00")
                            .font(.headline)
                            .foregroundStyle(Color.black)
                            .bold()
                            .padding()
                    }
                }
                HStack{
                    Text("Meta")
                        .font(.title2)
                        .foregroundStyle(Color.black)
                        .bold()
                        .padding()
                    Spacer()
                    Text("R$ 3.000,00")
                        .font(.headline)
                        .foregroundStyle(Color.black)
                        .bold()
                        .padding()
                }
                Spacer()
            }
        }
        
    }
}

struct Familia: View{
    var body: some View{
        
        ZStack{
            Rectangle()
                .fill(Color.malva)
                .edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
        }
        
    }
}

struct Ajustes: View{
    var body: some View{
        
        ZStack{
            Rectangle()
                .fill(Color.malva)
                .edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
        }
        
    }
}



#Preview {
    Tab()
}
